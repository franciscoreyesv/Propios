//var client = ZAFClient.init();

//client.on('app.registered', inicio);


//function inicio(){
//	let compiled = 'dddddd';
//	$('#app').html(compiled);
//}

